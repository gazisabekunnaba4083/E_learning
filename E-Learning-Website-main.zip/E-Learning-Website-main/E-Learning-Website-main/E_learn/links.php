<?php
  $links = array(
    'js' => 'waypoints.min.js'
  );
?>
